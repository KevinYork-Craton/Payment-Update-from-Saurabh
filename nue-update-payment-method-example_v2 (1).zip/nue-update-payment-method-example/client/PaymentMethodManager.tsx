'use client';

import { Elements, PaymentElement, useElements, useStripe } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useMemo, useState } from 'react';

/**
 * PaymentMethodManager
 *
 * Lets a customer manage the payment methods on file at any time, without
 * placing an order:
 *  - lists the methods on file and shows which one is the default
 *  - makes any existing method the default
 *  - adds a new card or US bank account (ACH)
 *  - verifies a manually entered bank account (microdeposits)
 *  - removes a non-default method
 *
 * "Default" is applied in two places together by the backend:
 *  1. Stripe: customer.invoice_settings.default_payment_method
 *  2. Nue: a PaymentMethod record linked via externalPaymentMethodId
 *
 * The browser never sees your Stripe secret key or Nue API key. It only
 * receives the short-lived SetupIntent client secret.
 */

interface PaymentMethodSummary {
  id: string; // Stripe payment method id
  type: 'card' | 'us_bank_account';
  card: { brand: string; last4: string; expMonth: number; expYear: number } | null;
  bank: { bankName: string | null; last4: string } | null;
  isDefault: boolean;
  nuePaymentMethodId: string | null;
}

interface PendingVerification {
  setupIntentId: string;
  bank: { bankName: string | null; last4: string };
  verificationType: string; // 'amounts' | 'descriptor_code'
}

interface PaymentMethodManagerProps {
  /** Nue customer ID of the logged-in customer */
  customerId: string;
  /** Base path of your backend routes, e.g. '/api' */
  apiBase: string;
  /** Stripe publishable key (pk_...), safe to expose to the browser */
  stripePublishableKey: string;
  /** Brand color applied to the Stripe Elements inputs (focus rings, selected tab) */
  brandColor?: string;
}

function methodLabel(pm: PaymentMethodSummary): string {
  if (pm.card) {
    return `${pm.card.brand.toUpperCase()} •••• ${pm.card.last4} · expires ${String(pm.card.expMonth).padStart(2, '0')}/${pm.card.expYear}`;
  }
  if (pm.bank) {
    return `${pm.bank.bankName ?? 'Bank account'} •••• ${pm.bank.last4} (ACH)`;
  }
  return pm.id;
}

export function PaymentMethodManager({
  customerId,
  apiBase,
  stripePublishableKey,
  brandColor = '#cf0913', // Fullbay red
}: PaymentMethodManagerProps) {
  const stripePromise = useMemo(() => loadStripe(stripePublishableKey), [stripePublishableKey]);

  const [methods, setMethods] = useState<PaymentMethodSummary[]>([]);
  const [pending, setPending] = useState<PendingVerification[]>([]);
  const [loading, setLoading] = useState(true);
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const fetchMethods = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${apiBase}/payment-methods?customerId=${encodeURIComponent(customerId)}`);
      if (!res.ok) throw new Error('Failed to load payment methods');
      const data = await res.json();
      setMethods(data.paymentMethods ?? []);
      setPending(data.pendingVerifications ?? []);
    } catch (e) {
      console.error(e);
      setError('Could not load your payment methods.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMethods();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customerId]);

  const callApi = async (path: string, method: string, body: object, successMessage: string) => {
    setError(null);
    setStatusMessage(null);
    try {
      const res = await fetch(`${apiBase}${path}`, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'Request failed');
      setStatusMessage(successMessage);
      await fetchMethods();
      return true;
    } catch (e) {
      console.error(e);
      setError(e instanceof Error ? e.message : 'Request failed.');
      return false;
    }
  };

  const startAdd = async () => {
    setError(null);
    setStatusMessage(null);
    try {
      const res = await fetch(`${apiBase}/payment-method/setup-intent`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ customerId }),
      });
      if (!res.ok) throw new Error('Failed to start payment method update');
      const data = await res.json();
      setClientSecret(data.clientSecret);
    } catch (e) {
      console.error(e);
      setError('Could not start the update. Please try again.');
    }
  };

  const onSaved = async () => {
    setClientSecret(null);
    setStatusMessage('Payment method added and set as default.');
    await fetchMethods();
  };

  // ACH entered manually verifies via microdeposits: the SetupIntent stays in
  // requires_action until the customer confirms the deposit amounts. It shows
  // in the list as pending with a verify action.
  const onPendingVerification = async () => {
    setClientSecret(null);
    setStatusMessage('Bank account added, pending microdeposit verification.');
    await fetchMethods();
  };

  return (
    <div style={{ maxWidth: 520 }}>
      <h2>Payment methods</h2>

      {loading ? (
        <p>Loading…</p>
      ) : methods.length === 0 && pending.length === 0 ? (
        <p>No payment methods on file.</p>
      ) : (
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {methods.map((pm) => (
            <MethodRow
              key={pm.id}
              pm={pm}
              onSetDefault={() =>
                callApi(
                  '/payment-method/set-default',
                  'POST',
                  { customerId, paymentMethodId: pm.id },
                  'Default payment method updated.',
                )
              }
              onRemove={() =>
                callApi('/payment-method', 'DELETE', { customerId, paymentMethodId: pm.id }, 'Payment method removed.')
              }
              onEdit={(expMonth, expYear) =>
                callApi(
                  '/payment-method',
                  'PATCH',
                  { customerId, paymentMethodId: pm.id, expMonth, expYear },
                  'Card updated.',
                )
              }
            />
          ))}
          {pending.map((pv) => (
            <PendingVerificationRow
              key={pv.setupIntentId}
              pv={pv}
              onVerify={(verification) =>
                callApi(
                  '/payment-method/verify-microdeposits',
                  'POST',
                  { customerId, setupIntentId: pv.setupIntentId, ...verification },
                  'Bank account verified and set as default.',
                )
              }
            />
          ))}
        </ul>
      )}

      {statusMessage && <p style={{ color: 'green' }}>{statusMessage}</p>}
      {error && <p style={{ color: 'crimson' }}>{error}</p>}

      {!clientSecret ? (
        <button onClick={startAdd}>Add payment method</button>
      ) : (
        <Elements
          stripe={stripePromise}
          options={{
            clientSecret,
            appearance: { variables: { colorPrimary: brandColor, borderRadius: '6px' } },
          }}
        >
          <NewMethodForm
            apiBase={apiBase}
            customerId={customerId}
            onSaved={onSaved}
            onPendingVerification={onPendingVerification}
            onCancel={() => setClientSecret(null)}
          />
        </Elements>
      )}
    </div>
  );
}

/**
 * One payment method on file. Cards can be edited (expiry only; a new number
 * is a new payment method, which is what the add flow is for). Non-default
 * methods can be promoted or removed.
 */
function MethodRow({
  pm,
  onSetDefault,
  onRemove,
  onEdit,
}: {
  pm: PaymentMethodSummary;
  onSetDefault: () => Promise<boolean>;
  onRemove: () => Promise<boolean>;
  onEdit: (expMonth: number, expYear: number) => Promise<boolean>;
}) {
  const [editing, setEditing] = useState(false);
  const [expMonth, setExpMonth] = useState(pm.card ? String(pm.card.expMonth).padStart(2, '0') : '');
  const [expYear, setExpYear] = useState(pm.card ? String(pm.card.expYear) : '');
  const [busy, setBusy] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);

  const run = async (fn: () => Promise<boolean>) => {
    setBusy(true);
    await fn();
    setBusy(false);
  };

  return (
    <li style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0' }}>
      <span>{methodLabel(pm)}</span>
      {editing ? (
        <span style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          <input style={{ width: 44 }} placeholder="MM" value={expMonth} onChange={(e) => setExpMonth(e.target.value)} />
          <input style={{ width: 60 }} placeholder="YYYY" value={expYear} onChange={(e) => setExpYear(e.target.value)} />
          <button
            disabled={busy}
            onClick={() => {
              const m = Number(expMonth);
              const y = Number(expYear);
              if (!Number.isInteger(m) || m < 1 || m > 12) {
                setEditError('Month must be 1-12.');
                return;
              }
              if (!Number.isInteger(y) || y < 2000 || y > 2100) {
                setEditError('Year must be four digits.');
                return;
              }
              setEditError(null);
              run(async () => {
                const ok = await onEdit(m, y);
                if (ok) setEditing(false);
                return ok;
              });
            }}
          >
            {busy ? 'Saving…' : 'Save'}
          </button>
          <button disabled={busy} onClick={() => setEditing(false)}>
            Cancel
          </button>
          {editError && <span style={{ color: 'crimson', fontSize: '0.85em' }}>{editError}</span>}
        </span>
      ) : (
        <span style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          {pm.isDefault && <strong>Default</strong>}
          {!pm.isDefault && (
            <button disabled={busy} onClick={() => run(onSetDefault)}>
              Make default
            </button>
          )}
          {pm.card && (
            <button disabled={busy} onClick={() => setEditing(true)}>
              Edit
            </button>
          )}
          {!pm.isDefault && (
            <button
              disabled={busy}
              onClick={() => {
                if (window.confirm('Remove this payment method?')) run(onRemove);
              }}
            >
              Remove
            </button>
          )}
        </span>
      )}
    </li>
  );
}

/**
 * A manually entered bank account waiting on microdeposit verification.
 * Depending on the verification type, the customer's bank statement shows
 * either two small deposit amounts (in cents) or one 6-character descriptor
 * code like SM11AA.
 */
function PendingVerificationRow({
  pv,
  onVerify,
}: {
  pv: PendingVerification;
  onVerify: (verification: { amounts: number[] } | { descriptorCode: string }) => Promise<boolean>;
}) {
  const [showForm, setShowForm] = useState(false);
  const [amount1, setAmount1] = useState('');
  const [amount2, setAmount2] = useState('');
  const [code, setCode] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const useCode = pv.verificationType === 'descriptor_code';

  return (
    <li style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0' }}>
      <span>
        {pv.bank.bankName ?? 'Bank account'} •••• {pv.bank.last4} (ACH) · pending verification
      </span>
      {!showForm ? (
        <button onClick={() => setShowForm(true)}>Verify</button>
      ) : (
        <span style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          {useCode ? (
            <input
              style={{ width: 90 }}
              placeholder="e.g. SM11AA"
              value={code}
              onChange={(e) => setCode(e.target.value)}
            />
          ) : (
            <>
              <input
                style={{ width: 64 }}
                placeholder="e.g. 32"
                value={amount1}
                onChange={(e) => setAmount1(e.target.value)}
              />
              <input
                style={{ width: 64 }}
                placeholder="e.g. 45"
                value={amount2}
                onChange={(e) => setAmount2(e.target.value)}
              />
            </>
          )}
          <button
            disabled={submitting}
            onClick={async () => {
              let verification: { amounts: number[] } | { descriptorCode: string };
              if (useCode) {
                if (!code.trim()) {
                  setFormError('Enter the descriptor code.');
                  return;
                }
                verification = { descriptorCode: code.trim() };
              } else {
                const a1 = Number(amount1);
                const a2 = Number(amount2);
                if (![a1, a2].every((n) => Number.isInteger(n) && n > 0)) {
                  setFormError('Enter both amounts as whole numbers (cents).');
                  return;
                }
                verification = { amounts: [a1, a2] };
              }
              setFormError(null);
              setSubmitting(true);
              const ok = await onVerify(verification);
              setSubmitting(false);
              if (ok) setShowForm(false);
            }}
          >
            {submitting ? 'Verifying…' : 'Submit'}
          </button>
          {formError && <span style={{ color: 'crimson', fontSize: '0.85em' }}>{formError}</span>}
        </span>
      )}
    </li>
  );
}

function NewMethodForm({
  apiBase,
  customerId,
  onSaved,
  onPendingVerification,
  onCancel,
}: {
  apiBase: string;
  customerId: string;
  onSaved: () => void;
  onPendingVerification: () => void;
  onCancel: () => void;
}) {
  const stripe = useStripe();
  const elements = useElements();
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    setSubmitting(true);
    setError(null);
    try {
      // Validates the method and saves it to the Stripe customer ($0 auth, no charge).
      const result = await stripe.confirmSetup({
        elements,
        redirect: 'if_required',
      });

      if (result.error) {
        setError(result.error.message ?? 'Payment method could not be saved.');
        return;
      }

      // Manually entered ACH stays in requires_action until microdeposits are verified.
      if (result.setupIntent.status === 'requires_action') {
        onPendingVerification();
        return;
      }

      // Tell the backend to make the new method the default.
      const confirmRes = await fetch(`${apiBase}/payment-method/confirm`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ customerId, setupIntentId: result.setupIntent.id }),
      });
      if (!confirmRes.ok) throw new Error('Failed to finalize payment method update');

      onSaved();
    } catch (err) {
      console.error(err);
      setError('Something went wrong saving your payment method. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <PaymentElement />
      {error && <p style={{ color: 'crimson' }}>{error}</p>}
      <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
        <button type="submit" disabled={!stripe || submitting}>
          {submitting ? 'Saving…' : 'Save payment method'}
        </button>
        <button type="button" onClick={onCancel} disabled={submitting}>
          Cancel
        </button>
      </div>
    </form>
  );
}
