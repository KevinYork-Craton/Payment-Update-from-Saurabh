import 'dotenv/config';
import express from 'express';
import path from 'path';
import { paymentMethodRouter } from './paymentMethodRoutes';

const app = express();

app.use('/api', paymentMethodRouter);

// Exposes only browser-safe config to the demo page.
app.get('/config', (_req, res) => {
  res.json({
    stripePublishableKey: process.env.STRIPE_PUBLISHABLE_KEY,
    testCustomerId: process.env.TEST_CUSTOMER_ID ?? '',
  });
});

app.use(express.static(path.join(__dirname, '..', 'public')));

const port = Number(process.env.PORT ?? 3456);
app.listen(port, () => {
  console.log(`Update Payment Method demo running at http://localhost:${port}`);
});
