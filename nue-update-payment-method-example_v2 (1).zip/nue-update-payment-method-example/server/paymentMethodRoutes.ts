/**
 * Payment method management routes (Express-style).
 *
 * Endpoints:
 *   GET    /payment-methods                       list methods on file, incl. pending ACH verifications
 *   POST   /payment-method/setup-intent           start adding a new method (card or ACH)
 *   POST   /payment-method/confirm                finish adding; new method becomes the default
 *   POST   /payment-method/set-default            make an existing method the default
 *   POST   /payment-method/verify-microdeposits   complete a manually entered ACH account
 *   PATCH  /payment-method                        update a card's expiry / billing details
 *   DELETE /payment-method                        remove a non-default method
 *
 * "Default" here means two things, applied together:
 *   1. Stripe: customer.invoice_settings.default_payment_method
 *   2. Nue: a PaymentMethod record linked via externalPaymentMethodId
 *
 * These run on YOUR server. They hold the Stripe secret key and the Nue API key;
 * neither is ever sent to the browser.
 *
 * If you use Next.js App Router instead of Express, each handler below maps 1:1
 * to a route handler (GET/POST) under app/api/; the bodies are identical.
 *
 * SECURITY: every handler must first verify that the authenticated portal user
 * owns the customerId it receives. That check is marked with TODOs below because
 * it depends on your session implementation.
 */

import express from 'express';
import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

const NUE_API_KEY = process.env.NUE_API_KEY!;
const NUE_API_URL = process.env.NUE_API_URL!; // e.g. https://api.nue.io
const NUE_SS_API_URL = process.env.NUE_SELF_SERVICE_API_URL!; // e.g. https://api.nue.io

export const paymentMethodRouter = express.Router();
paymentMethodRouter.use(express.json());

interface NuePaymentMethod {
  id: string;
  accountId: string;
  externalPaymentMethodId: string; // Stripe payment method id (pm_...)
  paymentSystem: string; // 'Stripe'
  paymentMethodType: string; // live records read back as 'Credit Card' (with a space) | 'ACH' | ...
  autoChargeEnabled: boolean;
}

const nueHeaders = { 'nue-api-key': NUE_API_KEY, 'Content-Type': 'application/json' };

// Only surface microdeposit verifications started recently. Stripe auto-cancels
// unverified ones after ~6 days, so this comfortably covers any genuinely
// pending account while keeping abandoned attempts out of the list.
const PENDING_VERIFICATION_LOOKBACK_SECONDS = 30 * 24 * 60 * 60;

/**
 * The customer's Stripe-linked PaymentMethod records in Nue.
 *
 * We filter by the `account` relation rather than the scalar `accountId`, which
 * throws a DataFetchingException for UUID (self-service-created) customer ids.
 * A single customer never has more than Nue's default page size of records, so
 * no pagination is needed. We then drop anything that isn't a usable Stripe
 * linkage.
 */
async function getNuePaymentMethods(nueCustomerId: string): Promise<NuePaymentMethod[]> {
  const res = await fetch(`${NUE_SS_API_URL}/orders/async/graphql`, {
    method: 'POST',
    headers: nueHeaders,
    body: JSON.stringify({
      query: `
        query ($id: ID!) {
          PaymentMethod(where: { account: { id: { _eq: $id } } }) {
            id
            accountId
            externalPaymentMethodId
            paymentSystem
            paymentMethodType
            autoChargeEnabled
          }
        }
      `,
      variables: { id: nueCustomerId },
    }),
  });

  if (!res.ok) return [];
  const parsed = await res.json();
  if (parsed?.errors?.length) {
    console.error('Nue GraphQL PaymentMethod query errors:', parsed.errors);
    return [];
  }
  const methods: NuePaymentMethod[] = parsed?.data?.PaymentMethod ?? [];
  return methods.filter((pm) => pm.paymentSystem === 'Stripe' && pm.externalPaymentMethodId);
}

/**
 * Derive the Stripe customer id from a method actually attached in Stripe.
 * Detached methods have no customer anymore, so keep trying until one resolves.
 */
async function deriveStripeCustomerIdFromMethods(
  nueCustomerId: string,
  nuePms?: NuePaymentMethod[],
): Promise<string | null> {
  const methods = nuePms ?? (await getNuePaymentMethods(nueCustomerId));
  for (const nuePm of methods) {
    try {
      const stripePm = await stripe.paymentMethods.retrieve(nuePm.externalPaymentMethodId);
      const customer = typeof stripePm.customer === 'string' ? stripePm.customer : stripePm.customer?.id;
      if (customer) return customer;
    } catch {
      // Payment method may no longer exist in Stripe; try the next one.
    }
  }
  return null;
}

/**
 * Look up the Stripe customer id from Nue's stored Stripe customer mapping.
 * This is what lets a customer with NO methods on file add their first one
 * (there is no attached method to derive from yet).
 *
 * NOTE: /stripe/customer-mapping is an app-surface endpoint, not part of the
 * public API reference — coordinate with your Nue contact before relying on it.
 * `keywords` is a fuzzy search (it can match by name or substring), so we
 * exact-match on sourceCustomerId; that filter is load-bearing for correctness
 * AND to avoid resolving another customer's Stripe id.
 */
async function getStripeCustomerIdFromMapping(nueCustomerId: string): Promise<string | null> {
  try {
    const res = await fetch(
      `${NUE_API_URL}/stripe/customer-mapping?keywords=${encodeURIComponent(nueCustomerId)}`,
      { headers: nueHeaders },
    );
    if (!res.ok) return null;
    const parsed = await res.json();
    const rows: Array<{ sourceCustomerId?: string; paymentCustomerId?: string }> = Array.isArray(parsed?.data)
      ? parsed.data
      : [];
    const stripeCustomerIds = [
      ...new Set(
        rows
          .filter((r) => r.sourceCustomerId === nueCustomerId && r.paymentCustomerId?.startsWith('cus_'))
          .map((r) => r.paymentCustomerId as string),
      ),
    ];
    if (stripeCustomerIds.length === 0) return null;
    if (stripeCustomerIds.length > 1) {
      // Ambiguous mapping: don't silently guess wrong. Surface it and use the first.
      console.warn(
        `Nue customer ${nueCustomerId} maps to multiple Stripe customers (${stripeCustomerIds.join(', ')}); using the first.`,
      );
    }
    return stripeCustomerIds[0];
  } catch (err) {
    console.error('Nue customer-mapping lookup failed:', err);
    return null;
  }
}

/**
 * Resolve the Stripe customer id for a Nue customer.
 *
 * Prefer deriving it from a method actually attached in Stripe: that reflects
 * ground truth and is immune to a stale or duplicated Nue->Stripe mapping. Only
 * when no attached method resolves it (none on file yet, or all detached) do we
 * fall back to Nue's stored customer mapping — which is what allows a customer
 * with zero methods to add their first one.
 */
async function getStripeCustomerId(nueCustomerId: string, nuePms?: NuePaymentMethod[]): Promise<string | null> {
  const fromMethods = await deriveStripeCustomerIdFromMethods(nueCustomerId, nuePms);
  if (fromMethods) return fromMethods;
  return getStripeCustomerIdFromMapping(nueCustomerId);
}

/**
 * Create/update the Nue PaymentMethod record linked to a Stripe payment method.
 *
 * This is the same endpoint Nue order activation uses when paymentMethodObject
 * is passed. It is an idempotent upsert keyed on externalPaymentMethodId per
 * customer. Requires the API user's Nue role to have the "Manage Payment
 * Methods" permission. Returns the Nue PaymentMethod id.
 */
async function upsertNuePaymentMethod(
  nueCustomerId: string,
  stripePaymentMethodId: string,
  displayName: string,
  paymentMethodType: 'CreditCard' | 'ACH',
): Promise<string> {
  const res = await fetch(`${NUE_API_URL}/billing/payment-methods:upsert`, {
    method: 'POST',
    headers: nueHeaders,
    body: JSON.stringify({
      paymentMethods: [
        {
          customerId: nueCustomerId,
          externalPaymentMethodId: stripePaymentMethodId,
          name: displayName,
          paymentMethodType,
          paymentSystem: 'Stripe',
          autoChargeEnabled: true,
        },
      ],
    }),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Nue payment-methods:upsert failed (${res.status}): ${text}`);
  }
  const parsed = await res.json();
  const nuePmId = parsed?.data?.upsertPaymentMethods?.[0]?.id;
  if (!nuePmId) throw new Error('Nue payment-methods:upsert returned no payment method id');
  return nuePmId;
}

/** Display name + Nue type for a Stripe payment method. */
function describeStripePm(pm: Stripe.PaymentMethod): { displayName: string; nueType: 'CreditCard' | 'ACH' } {
  if (pm.us_bank_account) {
    return {
      displayName: `${pm.us_bank_account.bank_name ?? 'Bank account'} •••• ${pm.us_bank_account.last4}`,
      nueType: 'ACH',
    };
  }
  return {
    displayName: pm.card ? `${pm.card.brand} •••• ${pm.card.last4}` : 'Card on file',
    nueType: 'CreditCard',
  };
}

/**
 * Make a Stripe payment method the default:
 * Stripe customer default + a linked Nue PaymentMethod record.
 */
async function makeDefault(
  nueCustomerId: string,
  stripeCustomerId: string,
  stripePaymentMethodId: string,
  nuePms?: NuePaymentMethod[],
) {
  const pm = await stripe.paymentMethods.retrieve(stripePaymentMethodId);
  const pmCustomer = typeof pm.customer === 'string' ? pm.customer : pm.customer?.id;
  if (pmCustomer !== stripeCustomerId) {
    throw Object.assign(new Error('Payment method does not belong to this customer'), { statusCode: 403 });
  }

  await stripe.customers.update(stripeCustomerId, {
    invoice_settings: { default_payment_method: stripePaymentMethodId },
  });

  // Reuse the existing Nue record when there is one; only upsert when this
  // Stripe payment method has no Nue record yet. The upsert is documented as
  // idempotent on externalPaymentMethodId, but we observed it creating a
  // duplicate record, so the example does not rely on server-side dedup.
  const existing = (nuePms ?? (await getNuePaymentMethods(nueCustomerId))).find(
    (n) => n.externalPaymentMethodId === stripePaymentMethodId,
  );
  let nuePmId: string;
  if (existing) {
    nuePmId = existing.id;
  } else {
    const { displayName, nueType } = describeStripePm(pm);
    nuePmId = await upsertNuePaymentMethod(nueCustomerId, stripePaymentMethodId, displayName, nueType);
  }

  return { nuePaymentMethodId: nuePmId };
}

/**
 * Decide what error detail is safe to return to the client. Stripe errors carry
 * user-facing messages (and may echo back submitted params, which is fine for a
 * self-service flow), and our own client errors are tagged with a statusCode.
 * Anything else (e.g. raw Nue API failures) becomes a generic message — the
 * full error is always logged server-side by the caller.
 */
function clientErrorResponse(err: any, fallback: string): { status: number; message: string } {
  if (err instanceof Stripe.errors.StripeError) {
    return { status: err.statusCode ?? 500, message: err.message };
  }
  if (typeof err?.statusCode === 'number') {
    return { status: err.statusCode, message: err.message ?? fallback };
  }
  return { status: 500, message: fallback };
}

/** Parse a value that should be a whole number, returning undefined if it isn't. */
function toInt(value: unknown): number | undefined {
  const n = typeof value === 'number' ? value : Number(value);
  return Number.isInteger(n) ? n : undefined;
}

/**
 * GET /payment-methods?customerId=...
 * Lists the methods on file with display details, which one is the default,
 * and the linked Nue PaymentMethod id (null if Nue has no record for it).
 */
paymentMethodRouter.get('/payment-methods', async (req, res) => {
  try {
    const customerId = String(req.query.customerId ?? '');
    if (!customerId) return res.status(400).json({ error: 'customerId is required' });

    // TODO: verify req.session user owns customerId. Return 403 otherwise.

    const nuePms = await getNuePaymentMethods(customerId);
    if (nuePms.length === 0) {
      return res.json({ paymentMethods: [], pendingVerifications: [], defaultPaymentMethodId: null });
    }

    const stripeCustomerId = await getStripeCustomerId(customerId, nuePms);
    if (!stripeCustomerId) {
      return res.json({ paymentMethods: [], pendingVerifications: [], defaultPaymentMethodId: null });
    }

    const customer = await stripe.customers.retrieve(stripeCustomerId);
    const def = customer.deleted ? null : customer.invoice_settings?.default_payment_method;
    const defaultPmId = typeof def === 'string' ? def : (def?.id ?? null);

    // Auto-paginate: the flow intentionally leaves old methods attached on each
    // add, so a long-lived customer can accumulate more than one page (100).
    const stripePms = await stripe.customers.listPaymentMethods(stripeCustomerId).autoPagingToArray({ limit: 1000 });
    const nueByExternalId = new Map(nuePms.map((pm) => [pm.externalPaymentMethodId, pm.id]));

    const paymentMethods = stripePms.map((pm) => ({
      id: pm.id,
      type: pm.us_bank_account ? 'us_bank_account' : 'card',
      card: pm.card
        ? { brand: pm.card.brand, last4: pm.card.last4, expMonth: pm.card.exp_month, expYear: pm.card.exp_year }
        : null,
      bank: pm.us_bank_account
        ? { bankName: pm.us_bank_account.bank_name, last4: pm.us_bank_account.last4 }
        : null,
      isDefault: pm.id === defaultPmId,
      nuePaymentMethodId: nueByExternalId.get(pm.id) ?? null,
    }));

    // Manually entered bank accounts that are still waiting on microdeposit
    // verification. Their payment method is not attached yet, so they only
    // show up via the SetupIntents that are parked in requires_action. Bound by
    // recency so abandoned attempts don't linger as phantom pending rows.
    const setupIntents = await stripe.setupIntents.list({
      customer: stripeCustomerId,
      created: { gte: Math.floor(Date.now() / 1000) - PENDING_VERIFICATION_LOOKBACK_SECONDS },
      limit: 100,
    });
    const attachedPmIds = new Set(stripePms.map((pm) => pm.id));
    const pendingVerifications = [];
    for (const si of setupIntents.data) {
      if (si.status !== 'requires_action' || si.next_action?.type !== 'verify_with_microdeposits') continue;
      const pmId = typeof si.payment_method === 'string' ? si.payment_method : si.payment_method?.id;
      if (!pmId || attachedPmIds.has(pmId)) continue;
      const pm = await stripe.paymentMethods.retrieve(pmId);
      if (!pm.us_bank_account) continue;
      pendingVerifications.push({
        setupIntentId: si.id,
        bank: { bankName: pm.us_bank_account.bank_name, last4: pm.us_bank_account.last4 },
        verificationType: si.next_action.verify_with_microdeposits?.microdeposit_type ?? 'amounts',
      });
    }

    return res.json({ paymentMethods, pendingVerifications, defaultPaymentMethodId: defaultPmId });
  } catch (err) {
    console.error('GET /payment-methods failed:', err);
    return res.status(500).json({ error: 'Failed to load payment methods' });
  }
});

/**
 * POST /payment-method/setup-intent  { customerId }
 * Creates a SetupIntent on the customer's existing Stripe customer and returns
 * its client secret. The browser uses this with Stripe Elements to collect and
 * save the new method. No charge is made.
 */
paymentMethodRouter.post('/payment-method/setup-intent', async (req, res) => {
  try {
    const { customerId } = req.body as { customerId?: string };
    if (!customerId) return res.status(400).json({ error: 'customerId is required' });

    // TODO: verify req.session user owns customerId. Return 403 otherwise.

    const stripeCustomerId = await getStripeCustomerId(customerId);
    if (!stripeCustomerId) {
      return res.status(404).json({ error: 'No Stripe customer on file for this account' });
    }

    const setupIntent = await stripe.setupIntents.create({
      customer: stripeCustomerId,
      usage: 'off_session', // allows charging the saved method later without the customer present
      payment_method_types: ['card', 'us_bank_account'],
    });

    return res.json({ clientSecret: setupIntent.client_secret });
  } catch (err) {
    console.error('POST /payment-method/setup-intent failed:', err);
    return res.status(500).json({ error: 'Failed to create setup intent' });
  }
});

/**
 * POST /payment-method/confirm  { customerId, setupIntentId }
 * Called after the browser successfully confirms the SetupIntent.
 * Verifies the SetupIntent belongs to this customer and succeeded, then makes
 * the new method the default (Stripe default + linked Nue PaymentMethod).
 *
 * NOTE: previous methods are intentionally left attached. If an in-flight
 * charge still references one, detaching would make that charge fail.
 */
paymentMethodRouter.post('/payment-method/confirm', async (req, res) => {
  try {
    const { customerId, setupIntentId } = req.body as { customerId?: string; setupIntentId?: string };
    if (!customerId || !setupIntentId) {
      return res.status(400).json({ error: 'customerId and setupIntentId are required' });
    }

    // TODO: verify req.session user owns customerId. Return 403 otherwise.

    const nuePms = await getNuePaymentMethods(customerId);
    const stripeCustomerId = await getStripeCustomerId(customerId, nuePms);
    if (!stripeCustomerId) {
      return res.status(404).json({ error: 'No Stripe customer on file for this account' });
    }

    const setupIntent = await stripe.setupIntents.retrieve(setupIntentId);

    if (setupIntent.status !== 'succeeded') {
      return res.status(400).json({ error: `SetupIntent is not complete (status: ${setupIntent.status})` });
    }
    const siCustomer = typeof setupIntent.customer === 'string' ? setupIntent.customer : setupIntent.customer?.id;
    if (siCustomer !== stripeCustomerId) {
      // Prevents one customer confirming a SetupIntent that belongs to another.
      return res.status(403).json({ error: 'SetupIntent does not belong to this customer' });
    }

    const newPaymentMethodId =
      typeof setupIntent.payment_method === 'string' ? setupIntent.payment_method : setupIntent.payment_method?.id;
    if (!newPaymentMethodId) {
      return res.status(400).json({ error: 'SetupIntent has no payment method' });
    }

    const result = await makeDefault(customerId, stripeCustomerId, newPaymentMethodId, nuePms);
    return res.json({ ok: true, ...result });
  } catch (err: any) {
    console.error('POST /payment-method/confirm failed:', err);
    const { status, message } = clientErrorResponse(err, 'Failed to finalize payment method');
    return res.status(status).json({ error: message });
  }
});

/**
 * POST /payment-method/set-default  { customerId, paymentMethodId }
 * Makes an EXISTING method (already attached to the Stripe customer) the
 * default (Stripe default + linked Nue PaymentMethod). Used when the customer
 * picks one of the methods already on file instead of adding a new one.
 */
paymentMethodRouter.post('/payment-method/set-default', async (req, res) => {
  try {
    const { customerId, paymentMethodId } = req.body as { customerId?: string; paymentMethodId?: string };
    if (!customerId || !paymentMethodId) {
      return res.status(400).json({ error: 'customerId and paymentMethodId are required' });
    }

    // TODO: verify req.session user owns customerId. Return 403 otherwise.

    const nuePms = await getNuePaymentMethods(customerId);
    const stripeCustomerId = await getStripeCustomerId(customerId, nuePms);
    if (!stripeCustomerId) {
      return res.status(404).json({ error: 'No Stripe customer on file for this account' });
    }

    const result = await makeDefault(customerId, stripeCustomerId, paymentMethodId, nuePms);
    return res.json({ ok: true, ...result });
  } catch (err: any) {
    console.error('POST /payment-method/set-default failed:', err);
    const { status, message } = clientErrorResponse(err, 'Failed to set default payment method');
    return res.status(status).json({ error: message });
  }
});

/**
 * POST /payment-method/verify-microdeposits  { customerId, setupIntentId, amounts?, descriptorCode? }
 * Completes a manually entered ACH account. The customer reads the two small
 * deposit amounts (or the 6-character descriptor code) from their bank
 * statement and submits them here. On success the account becomes the default.
 */
paymentMethodRouter.post('/payment-method/verify-microdeposits', async (req, res) => {
  try {
    const { customerId, setupIntentId, amounts, descriptorCode } = req.body as {
      customerId?: string;
      setupIntentId?: string;
      amounts?: number[];
      descriptorCode?: string;
    };
    if (!customerId || !setupIntentId || (!amounts && !descriptorCode)) {
      return res
        .status(400)
        .json({ error: 'customerId, setupIntentId, and amounts or descriptorCode are required' });
    }
    // Validate here rather than letting NaN/garbage reach Stripe. Amounts wins
    // when both are present (matches the verifyMicrodeposits call below).
    if (amounts !== undefined) {
      if (!Array.isArray(amounts) || amounts.length !== 2 || amounts.some((a) => (toInt(a) ?? 0) <= 0)) {
        return res.status(400).json({ error: 'amounts must be two positive whole-number (cents) values' });
      }
    } else if (typeof descriptorCode !== 'string' || descriptorCode.trim() === '') {
      return res.status(400).json({ error: 'descriptorCode must be a non-empty string' });
    }

    // TODO: verify req.session user owns customerId. Return 403 otherwise.

    const nuePms = await getNuePaymentMethods(customerId);
    const stripeCustomerId = await getStripeCustomerId(customerId, nuePms);
    if (!stripeCustomerId) {
      return res.status(404).json({ error: 'No Stripe customer on file for this account' });
    }

    const setupIntent = await stripe.setupIntents.retrieve(setupIntentId);
    const siCustomer = typeof setupIntent.customer === 'string' ? setupIntent.customer : setupIntent.customer?.id;
    if (siCustomer !== stripeCustomerId) {
      return res.status(403).json({ error: 'SetupIntent does not belong to this customer' });
    }

    const verified = await stripe.setupIntents.verifyMicrodeposits(
      setupIntentId,
      amounts ? { amounts } : { descriptor_code: descriptorCode },
    );
    if (verified.status !== 'succeeded') {
      return res.status(400).json({ error: `Verification did not complete (status: ${verified.status})` });
    }

    const pmId = typeof verified.payment_method === 'string' ? verified.payment_method : verified.payment_method?.id;
    if (!pmId) return res.status(400).json({ error: 'SetupIntent has no payment method' });

    const result = await makeDefault(customerId, stripeCustomerId, pmId, nuePms);
    return res.json({ ok: true, ...result });
  } catch (err: any) {
    console.error('POST /payment-method/verify-microdeposits failed:', err);
    // Stripe raises a clear, user-safe error for wrong amounts/codes; it is
    // surfaced to the client by clientErrorResponse.
    const { status, message } = clientErrorResponse(err, 'Failed to verify bank account');
    return res.status(status).json({ error: message });
  }
});

/**
 * PATCH /payment-method  { customerId, paymentMethodId, expMonth?, expYear?, billingName?, billingZip? }
 * Updates what Stripe allows updating on an existing method: a card's expiry
 * (e.g. the bank reissued the same card with a new date) and billing details.
 * The card or account NUMBER can never be edited; a new number is a new
 * payment method by definition, which is what the add flow is for.
 *
 * The Nue record is intentionally not touched: it links by the Stripe payment
 * method id, which does not change on an edit, and display labels are read
 * from Stripe.
 */
paymentMethodRouter.patch('/payment-method', async (req, res) => {
  try {
    const { customerId, paymentMethodId, expMonth, expYear, billingName, billingZip } = req.body as {
      customerId?: string;
      paymentMethodId?: string;
      expMonth?: number;
      expYear?: number;
      billingName?: string;
      billingZip?: string;
    };
    if (!customerId || !paymentMethodId) {
      return res.status(400).json({ error: 'customerId and paymentMethodId are required' });
    }
    if (!expMonth && !expYear && !billingName && !billingZip) {
      return res.status(400).json({ error: 'Nothing to update' });
    }
    // Reject malformed expiry up front rather than silently dropping NaN/0 (the
    // `if (expMonth)` coercion below would otherwise treat them as "not set").
    if (expMonth !== undefined) {
      const m = toInt(expMonth);
      if (m === undefined || m < 1 || m > 12) {
        return res.status(400).json({ error: 'expMonth must be a whole number between 1 and 12' });
      }
    }
    if (expYear !== undefined) {
      const y = toInt(expYear);
      if (y === undefined || y < 2000 || y > 2100) {
        return res.status(400).json({ error: 'expYear must be a four-digit year' });
      }
    }

    // TODO: verify req.session user owns customerId. Return 403 otherwise.

    const stripeCustomerId = await getStripeCustomerId(customerId);
    if (!stripeCustomerId) {
      return res.status(404).json({ error: 'No Stripe customer on file for this account' });
    }

    const pm = await stripe.paymentMethods.retrieve(paymentMethodId);
    const pmCustomer = typeof pm.customer === 'string' ? pm.customer : pm.customer?.id;
    if (pmCustomer !== stripeCustomerId) {
      return res.status(403).json({ error: 'Payment method does not belong to this customer' });
    }

    const update: Stripe.PaymentMethodUpdateParams = {};
    if (expMonth || expYear) {
      if (!pm.card) return res.status(400).json({ error: 'Expiry can only be updated on cards' });
      update.card = {
        ...(expMonth ? { exp_month: expMonth } : {}),
        ...(expYear ? { exp_year: expYear } : {}),
      };
    }
    if (billingName || billingZip) {
      update.billing_details = {
        ...(billingName ? { name: billingName } : {}),
        ...(billingZip ? { address: { postal_code: billingZip } } : {}),
      };
    }

    const updated = await stripe.paymentMethods.update(paymentMethodId, update);
    return res.json({
      ok: true,
      card: updated.card
        ? {
            brand: updated.card.brand,
            last4: updated.card.last4,
            expMonth: updated.card.exp_month,
            expYear: updated.card.exp_year,
          }
        : null,
    });
  } catch (err: any) {
    console.error('PATCH /payment-method failed:', err);
    const { status, message } = clientErrorResponse(err, 'Failed to update payment method');
    return res.status(status).json({ error: message });
  }
});

/**
 * DELETE /payment-method  { customerId, paymentMethodId }
 * Removes a method that is NOT the current default. Detaching in Stripe also
 * notifies Nue's Stripe integration (payment_method.detached webhook), which
 * cleans up the Nue-side mapping.
 */
paymentMethodRouter.delete('/payment-method', async (req, res) => {
  try {
    const { customerId, paymentMethodId } = req.body as { customerId?: string; paymentMethodId?: string };
    if (!customerId || !paymentMethodId) {
      return res.status(400).json({ error: 'customerId and paymentMethodId are required' });
    }

    // TODO: verify req.session user owns customerId. Return 403 otherwise.

    const stripeCustomerId = await getStripeCustomerId(customerId);
    if (!stripeCustomerId) {
      return res.status(404).json({ error: 'No Stripe customer on file for this account' });
    }

    const pm = await stripe.paymentMethods.retrieve(paymentMethodId);
    const pmCustomer = typeof pm.customer === 'string' ? pm.customer : pm.customer?.id;
    if (pmCustomer !== stripeCustomerId) {
      return res.status(403).json({ error: 'Payment method does not belong to this customer' });
    }

    // Never remove the default: an auto-charge could be about to use it.
    const customer = await stripe.customers.retrieve(stripeCustomerId);
    const def = customer.deleted ? null : customer.invoice_settings?.default_payment_method;
    const defaultPmId = typeof def === 'string' ? def : def?.id;
    if (paymentMethodId === defaultPmId) {
      return res
        .status(400)
        .json({ error: 'This is the default payment method. Set another method as default first.' });
    }

    await stripe.paymentMethods.detach(paymentMethodId);
    return res.json({ ok: true });
  } catch (err: any) {
    console.error('DELETE /payment-method failed:', err);
    const { status, message } = clientErrorResponse(err, 'Failed to remove payment method');
    return res.status(status).json({ error: message });
  }
});
