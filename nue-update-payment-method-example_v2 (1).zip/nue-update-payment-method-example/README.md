# Payment Method Manager (Self-Service) Example

This example shows how to let your customers **manage the payment methods on file at any time, without placing a new order**. It supports **credit cards** and **ACH (US bank accounts)** and covers the full lifecycle:

- list the methods on file and show which one is the default
- add a new card or bank account (no charge is made)
- make any existing method the default
- edit a card's expiry and billing details (for reissued cards)
- verify a manually entered bank account (microdeposits) in-app
- remove a method that is not the default

> **About this example.** This is reference code provided to illustrate an integration pattern. It is not an officially supported Nue product or component. Please review it, adapt it to your codebase, and test it thoroughly in your sandbox before any production use. A first-class Nue UI component for managing payment methods is on the roadmap and will be the supported path once it ships.

Everything here runs in your environment with your credentials: your front end, your backend, your Stripe account, and your Nue API key. Nue does not host any part of this flow.

## Architecture

A thin backend layer keeps your Nue API key and Stripe secret key on your server; the browser only ever sees a short-lived Stripe SetupIntent client secret. Card and bank details are collected by Stripe's PaymentElement inside Stripe's secure iframe, so they never touch your page or your server.

```
Browser (React + Stripe Elements)        Your backend                            Stripe / Nue
─────────────────────────────────        ────────────                            ────────────
List methods ──────────────────────────► GET  /payment-methods ───────────────►  Nue GraphQL (PaymentMethod records)
                                                                                  Stripe listPaymentMethods + SetupIntents
Add method ────────────────────────────► POST /payment-method/setup-intent ───►  Stripe setupIntents.create
  PaymentElement + confirmSetup() ─────────────────────────────────────────────► Stripe (method saved, $0 auth)
  on success ──────────────────────────► POST /payment-method/confirm ────────►  Stripe default + Nue payment-methods:upsert
Make default ──────────────────────────► POST /payment-method/set-default ────►  Stripe default + Nue record (reused or upserted)
Verify bank account ───────────────────► POST /payment-method/verify-microdeposits ► Stripe verify + default + Nue record
Edit card expiry ──────────────────────► PATCH /payment-method ───────────────►  Stripe paymentMethods.update (same pm id)
Remove ────────────────────────────────► DELETE /payment-method ──────────────►  Stripe paymentMethods.detach
```

Every method ends up represented on both sides: attached to the customer in Stripe, and linked in Nue through a `PaymentMethod` record whose `externalPaymentMethodId` is the Stripe payment method id (type `CreditCard` or `ACH`).

## Files

- `client/PaymentMethodManager.tsx` is a drop-in React component implementing the full manager UI.
- `server/paymentMethodRoutes.ts` contains the Express route handlers. If you are on Next.js, each handler maps 1:1 to a route handler under `app/api/`; the logic is identical.
- `server/index.ts` and `public/index.html` are a runnable demo harness. The HTML page is a vanilla-JS mirror of the React component, useful for trying the flow before wiring it into your app.

## Running the demo

```bash
npm install
cp .env.example .env   # fill in your keys
npm run dev            # then open http://localhost:3456
```

Add `?pm=ach` to the URL to show the bank-account tab first.

For the React component in your own app:

```bash
npm install @stripe/stripe-js @stripe/react-stripe-js
```

```tsx
<PaymentMethodManager
  customerId={nueCustomerId}
  apiBase="/api"
  stripePublishableKey={STRIPE_PUBLISHABLE_KEY}
/>
```

## Testing in Stripe test mode

- **Cards:** `4242 4242 4242 4242` (Visa) or `5555 5555 5555 4444` (Mastercard), any future expiry, any CVC and ZIP.
- **ACH, instant verification:** pick the **Test Institution** in the bank picker and choose the success account. The SetupIntent succeeds immediately and the method is added in one sitting.
- **ACH, manual entry:** routing `110000000`, account `000123456789`. The account shows in the list as "Pending verification"; complete it with the test values, amounts `32` and `45` or descriptor code `SM11AA`.

## Important notes (please read before shipping)

1. **Your portal owns authentication and authorization.** The example assumes your application already authenticates the customer. Before serving any of these endpoints, verify that the logged-in user owns the `customerId` they are acting on (the spots are marked with TODOs in the routes). Without that check, any signed-in user could read or change another customer's payment methods.

2. **The Nue side uses `POST /billing/payment-methods:upsert`.** This is the same endpoint Nue's own order activation uses when a `paymentMethodObject` is passed; here it is called directly so no order is needed. Three things to know:
   - This endpoint is not yet in the public API reference. It is available today, but please coordinate with your Nue contact before building on it so we can keep you informed of any changes ahead of the official component release.
   - The Nue role behind your API key needs the **Manage Payment Methods** permission. Without it the call fails with "API Key is not allowed for this endpoint".
   - The upsert is documented as idempotent on `externalPaymentMethodId`, but in our testing it could create a duplicate record. The example therefore reuses the existing Nue record when one exists and only upserts when there is none.

3. **ACH verification.** Instant verification (bank login through the Stripe modal) completes immediately. Manually entered bank details verify via microdeposits over 1 to 2 business days; the account appears in the list as pending, and the customer completes it in-app by entering the two deposit amounts or the descriptor code from their bank statement. Depending on the account, Stripe uses one or the other; the UI shows the right input automatically. If you prefer cards only, change `payment_method_types` to `['card']` in the setup-intent route.

4. **Editing methods.** Only a card's expiry and billing details can change on an existing method; the number can never be edited because a new number is a new payment method by definition (use Add for that). Edits are Stripe-only mutations of the same payment method object, so the Nue record's link via `externalPaymentMethodId` remains valid and no Nue call is made.

5. **Removing methods.** The default method cannot be removed; the customer must promote another method first. Removal detaches the method in Stripe only. When your Stripe account is connected to Nue, the `payment_method.detached` event should also clean up the Nue-side mapping; please verify this in your sandbox. Either way, a leftover Nue record is benign here: the list is driven by the methods attached in Stripe, so a detached method never displays and can never be selected.

6. **SetupIntent, not PaymentIntent.** Adding a method performs a $0 authorization to validate and save it. `usage: 'off_session'` is what allows it to be charged later without the customer present.

7. **GraphQL lookup workaround.** Filtering `PaymentMethod` by `accountId` on the Nue GraphQL endpoint currently errors, so the backend fetches and filters in code. Once the filter is fixed, this can switch back to a `where: { accountId: { _eq: ... } }` query.
